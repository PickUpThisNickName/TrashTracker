﻿using System.IO;
using System.Security.Cryptography.X509Certificates;

string[] strings =
    File.ReadAllLines(
        "D:\\Загрузки (Chrome)\\dataset\\video2\\video2.txt",
        System.Text.Encoding.UTF8);

for (int k = 0; k < 335; k++)
{
    //new File

    List<string> Lines = new List<string>();

    for (int i = 0; i < strings.Length; i++)
    {
        var Splittedstring = strings[i].Split(", ");
        if (Splittedstring[0] == k.ToString())
        {
            //append new line to file
            Lines.Add(Splittedstring[2] + " "
                + Splittedstring[3] + " "
                + Splittedstring[4] + " "
                + Splittedstring[5] + " "
                + Splittedstring[6]);

        }
    }

    File.WriteAllLines(
        "D:\\Загрузки (Chrome)\\dataset\\video2\\video_2_" + k.ToString("0000")
        + ".txt", Lines);
}